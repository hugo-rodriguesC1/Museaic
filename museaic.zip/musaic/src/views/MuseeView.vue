<template>
  <div class="grid w-full bg-gray-900 grid-cols-6 gap-5 px-5 py-12 h-full">
    <div
      class="
        bg-white
        col-span-4
        row-span-2
        grid grid-cols-6
        auto-rows-[minmax(80px,93.5px)]
      "
    >
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
      <div
        class="border-red-700 border"
        @dragover.prevent
        @drop.prevent="drop"
      ></div>
    </div>
    <router-link to="/museemodif"
      ><div class="bg-white">Modifier</div></router-link
    >
  </div>
</template>

<script>
export default {
  name: "Musee",
  methods: {
    dragStart: (e) => {
      const target = e.target;
      e.dataTransfer.setData("imgID", target.id);
      // setTimeout(() => {
      //   target.style.display = "none";
      // }, 0);
    },
    drop: (e) => {
      const imgID = e.dataTransfer.getData("imgID");
      const img = document.getElementById(imgID);
      img.style.display = "block";
      e.target.appendChild(img);
    },
  },
};
</script>
